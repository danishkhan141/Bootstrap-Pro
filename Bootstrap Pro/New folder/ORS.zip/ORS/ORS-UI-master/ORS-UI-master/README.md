# ORS-UI  
## Online Result System Wireframe
1. HTML UI 
* see ORS-UI/html
1. HTML + CSS UI
* see ORS-UI/htmlcss
1. HTML +CSS + JavaScript UI
* see ORS-UI/htmljs
1. Bootstrap UI
* see ORS-UI/bs
